#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <netinet/in.h>

void usage() {
	printf("syntax : add_nbo <file1> <file2>\n");
	printf("sample : add_nbo a.bin c.bin\n");
}

uint32_t getNumber(char* fileName) {
	FILE* fp = fopen(fileName, "rb");
	if (fp == nullptr) {
		fprintf(stderr, "file open(%s) failed", fileName);
		exit(-1);
	}

	uint32_t res;
	size_t readLen = fread(&res, 1, sizeof(uint32_t), fp);
	if (readLen != sizeof(uint32_t)) {
		printf("file read failed readLen=%lu\n", readLen);
		exit(-1);
	}
	fclose(fp);

	res = ntohl(res);
	return res;
}

int main(int argc, char* argv[]) {
	if (argc != 3) {
		usage();
		exit(0);
	}
	uint32_t a = getNumber(argv[1]);
	uint32_t b = getNumber(argv[2]);
	printf("%d(0x%x) + %d(0x%x) = %d(0x%x)\n", a, a, b, b, a + b, a + b);
}
