#include <stdlib.h>
#include <stdio.h>

void usage() {
	printf("syntax : asmd_test <number1> <number2>\n");
	printf("sample : asmd_test 10 5\n");
}

void writeAdd(int a, int b) {
	int c = a + b;
	printf("%d + %d = %d\n", a, b, c);
}

void writeSub(int a, int b) {
	int c = a - b;
	printf("%d - %d = %d\n", a, b, c);
}

void writeMul(int a, int b) {
	int c = a * b;
	printf("%d * %d = %d\n", a, b, c);
}

void writeDiv(int a, int b) {
	int c = a / b;
	printf("%d / %d = %d\n", a, b, c);
}

int main(int argc, char* argv[]) {
	printf("begin\n");
	if (argc != 3) {
		usage();
		return -1;
	}
	int a = atoi(argv[1]);
	int b = atoi(argv[2]);
	writeAdd(a, b);
	writeSub(a, b);
	writeMul(a, b);
	writeDiv(a, b);
	printf("end\n");
}

