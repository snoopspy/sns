
[sample list]
1. Obtaining the device list
2. Obtaining advanced information about installed devices
3. Opening an adapter and capturing the packets
4. Capturing the packets without the callback
5. Filtering the traffic
6. Interpreting the packets
7. Handling offline dump files
8. Sending Packets
9. Gathering Statistics on the network traffic

[sample 제작 방법 - 공통]

1. 프로젝트를 생성한다.
   Qt - File - New - Applications - Qt Console Application - 프로젝트명(sample1) - Debug 및 Release 폴더에 '.'를 적어 주고 프로젝트를 생성한다.

2. main.cpp 파일에 소스를 작업한다.

3. 컴파일하면 pcap.h 파일을 찾을 수 없다는 에러가 나온다.

4. pro 파일에 include path를 넣어 줘서 pcap.h을 정상적으로 include할 수 있도록 해 준다.
   pro 파일이 변경된 경우에는 "Run qmake" 명령어를 통하여 프로젝트 빌드 정책이 변경될 수 있도록 한다.

   INCLUDEPATH  += D:/project/net/winpcap/Include

5. 재컴파일하면 'PCAP_SRC_IF_STRING' 에러가 난다. 이 경우 다음과 같은 2개의 preprocessor를 pcap.h 파일을 include하기 이전에 넣어 준다.

  #define  WPCAP
  #define  HAVE_REMOTE
  #include <pcap.h>
  
6. 컴파일을 하면 unsesolved external.." 링크 에러가 난다.
   이 경우 pro file에서 wpcap.lib 파일을 링크시켜 주도록 한다
   확장자(.lib)는 명시하지 않는다.

  LIBS += -lD:/project/net/winpcap/Lib/wpcap

7. 컴파일 및 링크를 성공시키고 실행이 제대로 되는지 확인한다.


[sample 2]

LIBS += -lWs2_32

[sample 5]
pcap_compile(adhandle, &fcode, "ip and tcp", 1, netmask) < 0) 부분에서 bpf filter의 값을 바꿔어 테스트해 본다.

[sample 6]
LIBS += -lWs2_32
