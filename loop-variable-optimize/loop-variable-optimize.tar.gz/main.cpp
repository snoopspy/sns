#include <cstdio>

void loopVariableUsed() {
	for (int i = 0; i < 100; i++) { // 100 == 0x64
		printf("%d\n", i);
	}
}

void loopVariableNotUsed() {
	for (int i = 0; i < 100; i++) {
		printf("*\n");
	}
}

void loopVariableNotUsed2() {
	for (int i = 0x1000 + 0; i < 0x1000 + 10; i++) { // 0x1000 = 4096
		printf("*\n");
	}
}

int main() {
	loopVariableUsed();
	loopVariableNotUsed();
	loopVariableNotUsed2();
}
