#include <iostream>

using namespace std;

void ifElseTest(int n) {
	if (n == 0) cout << "zero" << endl;
	else if (n == 1) cout << "one" << endl;
	else if (n == 2) cout << "two" << endl;
	else if (n == 3) cout << "three" << endl;
	else if (n == 4) cout << "four" << endl;
	else if (n == 5) cout << "five" << endl;
	else if (n == 6) cout << "six" << endl;
	else if (n == 7) cout << "seven" << endl;
	else if (n == 8) cout << "eight" << endl;
	else if (n == 9) cout << "nine" << endl;
	else if (n == 10) cout << "ten" << endl;
	else cout << "other" << endl;
}

void switchTest(int n) {
	switch (n) {
		case 0: cout << "zero" << endl; break;
		case 1: cout << "one" << endl; break;
		case 2: cout << "two" << endl; break;
		case 3: cout << "three" << endl; break;
		case 4: cout << "four" << endl; break;
		case 5: cout << "five" << endl; break;
		case 6: cout << "six" << endl; break;
		case 7: cout << "seven" << endl; break;
		case 8: cout << "eight" << endl; break;
		case 9: cout << "nine" << endl; break;
		case 10: cout << "ten" << endl; break;
		default: cout << "other" << endl; break;
	}
}

void sparseSwitchTest(int n) {
	switch (n) {
		case 0x00: cout << "zero * 0x10" << endl; break;
		case 0x10: cout << "one * 0x10" << endl; break;
		case 0x20: cout << "two * 0x10" << endl; break;
		case 0x30: cout << "three * 0x10" << endl; break;
		case 0x40: cout << "four * 0x10" << endl; break;
		case 0x50: cout << "five * 0x10" << endl; break;
		case 0x60: cout << "six * 0x10" << endl; break;
		case 0x70: cout << "seven * 0x10" << endl; break;
		case 0x80: cout << "eight * 0x10" << endl; break;
		case 0x90: cout << "nine * 0x10" << endl; break;
		case 0xA0: cout << "ten * 0x10" << endl; break;
		default: cout << "other * 0x10" << endl; break;
	}
}

int main(int, char* argv[]) {
	int n = stoi(argv[1]);
	ifElseTest(n);
	switchTest(n);
	sparseSwitchTest(n);
}
